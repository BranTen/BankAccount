package lab10;

public class CheckingAccount extends BankAccount{
static double FEE = 0.15;
String name;
double amount;
String accNum;

	public  CheckingAccount(String name, int amount) {
		// TODO Auto-generated constructor stub
		super(name, amount);
		accNum = super.getAccountNumber() + "-10";
		this.name = name;
		this.amount = amount;
	}


	public String getAccountNumber() {
		// TODO Auto-generated method stub
		return accNum;
	}

	public String getOwner() {
		// TODO Auto-generated method stub
		return name;
	}

	public double getBalance() {
		// TODO Auto-generated method stub
		return amount;
	}

	public void deposit(double put_in) {
		// TODO Auto-generated method stub
		amount = amount + put_in;
	}

	public boolean withdraw(double take_out) {
		// TODO Auto-generated method stub
		double total;
		total = take_out + FEE;
		super.withdraw(total);
		amount = amount - total;
		return super.withdraw(total);
	}

}
