package lab10;

public class SavingsAccount extends BankAccount{
	//annual intrest rate
	double rate = 2.5;
	//savings account number
	int savingsNumber = 0;
	double monthlyInterestRate;
	double monthlyIntrest;
	double amount;
	String name;
	String accountNumber;

	public SavingsAccount(String string, double i) {
		// TODO Auto-generated constructor stub
		super(string, i);
		accountNumber = super.getAccountNumber() + "-" +  savingsNumber;
		amount = i;
		name = string;
	}

	public SavingsAccount(SavingsAccount yourAccount, int amount) {
		// TODO Auto-generated constructor stub
		super(yourAccount, amount);
		savingsNumber++;
		accountNumber = super.getAccountNumber() + "-" +  savingsNumber;
		name = yourAccount.getOwner();
		this.amount = amount;
	}

	public String getAccountNumber() {
		// TODO Auto-generated method stub
		return accountNumber;
	}

	public String getOwner() {
		// TODO Auto-generated method stub
		return name;
	}

	public double getBalance() {
		// TODO Auto-generated method stub
		return amount;
	}

	public void deposit(double put_in) {
		// TODO Auto-generated method stub
		amount = amount + put_in;

	}

	public boolean withdraw(double take_out) {
		// TODO Auto-generated method stub
		if(super.withdraw(take_out)==true){
		amount = amount - take_out;
		}
		return super.withdraw(take_out);
	}

	public void postInterest() {
		// TODO Auto-generated method stub
		monthlyInterestRate = rate / 1200;
		monthlyIntrest = amount * monthlyInterestRate;
		deposit(monthlyIntrest);
	}

}
